package com.vivek.RetailManagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vivek.RetailManagement.entity.Store;

public interface StoreRepository extends JpaRepository <Store,Integer> {
	@Query("Select s from Store s order by s.updatedOn Desc")
    List<Store>FindAllByOrderByUpdatedOnDesc();
	@Query("Select s.storeNumber from Store s")
    List<Integer> findStores();
}
