package com.vivek.RetailManagement.ItemBean;

import java.sql.Date;
import java.time.LocalDateTime;

public class StoreBean {
	private Integer storeNumber;	
	private String storeName;
	private String storePattern;
	private String storeLocation;
	private String state;
	private Integer pinCode;
	private Date storeStartDate;
	private Date storeEndDate;
	private LocalDateTime createdOn;
	private LocalDateTime updatedOn;
	public Integer getStoreNumber() {
		return storeNumber;
	}
	public void setStoreNumber(Integer storeNumber) {
		this.storeNumber = storeNumber;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getStorePattern() {
		return storePattern;
	}
	public void setStorePattern(String storePattern) {
		this.storePattern = storePattern;
	}
	public String getStoreLocation() {
		return storeLocation;
	}
	public void setStoreLocation(String storeLocation) {
		this.storeLocation = storeLocation;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Integer getPinCode() {
		return pinCode;
	}
	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}
	public Date getStoreStartDate() {
		return storeStartDate;
	}
	public void setStoreStartDate(Date storeStartDate) {
		this.storeStartDate = storeStartDate;
	}
	public Date getStoreEndDate() {
		return storeEndDate;
	}
	public void setStoreEndDate(Date storeEndDate) {
		this.storeEndDate = storeEndDate;
	}
	public LocalDateTime getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}
	public LocalDateTime getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(LocalDateTime updatedOn) {
		this.updatedOn = updatedOn;
	}
	public StoreBean(Integer storeNumber, String storeName, String storePattern, String storeLocation, String state,
			Integer pinCode, Date storeStartDate, Date storeEndDate, LocalDateTime createdOn, LocalDateTime updatedOn) {
		super();
		this.storeNumber = storeNumber;
		this.storeName = storeName;
		this.storePattern = storePattern;
		this.storeLocation = storeLocation;
		this.state = state;
		this.pinCode = pinCode;
		this.storeStartDate = storeStartDate;
		this.storeEndDate = storeEndDate;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}
	public StoreBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
