package com.vivek.RetailManagement.entity;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.lang.NonNull;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Data;

@Entity
@Data
@Table(name = "store")
public class Store {
	
	@Id
	private Integer storeNumber;

	@NonNull
	private String storeName;
	private String storePattern;
	private String storeLocation;
	private String state;
	private Integer pinCode;
	@NonNull
	private Date storeStartDate;
	private Date storeEndDate;
	
	@NonNull
	@CreationTimestamp
	private LocalDateTime createdOn;
	
	@UpdateTimestamp
	private LocalDateTime updatedOn;

	public Integer getStoreNumber() {
		return storeNumber;
	}

	public void setStoreNumber(Integer storeNumber) {
		this.storeNumber = storeNumber;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getStorePattern() {
		return storePattern;
	}

	public void setStorePattern(String storePattern) {
		this.storePattern = storePattern;
	}

	public String getStoreLocation() {
		return storeLocation;
	}

	public void setStoreLocation(String storeLocation) {
		this.storeLocation = storeLocation;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Integer getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public Date getStoreStartDate() {
		return storeStartDate;
	}

	public void setStoreStartDate(Date storeStartDate) {
		this.storeStartDate = storeStartDate;
	}

	public Date getStoreEndDate() {
		return storeEndDate;
	}

	public void setStoreEndDate(Date storeEndDate) {
		this.storeEndDate = storeEndDate;
	}

	public LocalDateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public LocalDateTime getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(LocalDateTime updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Store(Integer storeNumber, String storeName, String storePattern, String storeLocation, String state,
			Integer pinCode, Date storeStartDate, Date storeEndDate, LocalDateTime createdOn, LocalDateTime updatedOn) {
		super();
		this.storeNumber = storeNumber;
		this.storeName = storeName;
		this.storePattern = storePattern;
		this.storeLocation = storeLocation;
		this.state = state;
		this.pinCode = pinCode;
		this.storeStartDate = storeStartDate;
		this.storeEndDate = storeEndDate;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}

	public Store() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}