package com.vivek.RetailManagement.Exceptions;


public class StoreAlreadyPresent extends RuntimeException{
	
	
	private static final long serialVersionUID = 1L;
	private String Message;
	public StoreAlreadyPresent() {
		
	}
	public StoreAlreadyPresent(String msg) {
		super(msg);
		this.Message=msg;
		
		
	}
	public String getMessage() {
		return Message;
	}
	public void setMessage(String message) {
		Message = message;
	}
	         	

}
