package com.vivek.RetailManagement.entity;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Embeddable;
import lombok.Data;
import lombok.EqualsAndHashCode;
@Data
@Embeddable
@EqualsAndHashCode
public class ItemPrime implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String itemNumber;
	private Date itemStartDate;
	public ItemPrime(String itemNumber, Date itemStartDate) {
		super();
		this.itemNumber = itemNumber;
		this.itemStartDate = itemStartDate;
	}
	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public Date getItemStartDate() {
		return itemStartDate;
	}
	public void setItemStartDate(Date itemStartDate) {
		this.itemStartDate = itemStartDate;
	}
	
	public ItemPrime() {
		super();
	}

}
	