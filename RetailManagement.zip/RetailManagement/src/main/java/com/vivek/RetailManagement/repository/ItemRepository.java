package com.vivek.RetailManagement.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.vivek.RetailManagement.entity.Item;
import com.vivek.RetailManagement.entity.ItemPrime;
@Repository
public interface ItemRepository extends JpaRepository <Item,ItemPrime> {

	
	@Query("Select i from Item i where i.itemPrime.itemNumber= :ItemNumber and i.itemPrime.itemStartDate= :ItemStartDate")
	public Item findByIdDate(String ItemNumber, Date ItemStartDate);
	@Transactional
	@Modifying
	@Query("Delete from Item i where i.itemPrime.itemNumber= :ItemNumber and i.itemPrime.itemStartDate= :ItemStartDate")
	public void deleteById(String ItemNumber, Date ItemStartDate);
	@Query("Select i from Item i order by i.updatedOn Desc")
	public List<Item> findAllByOrderByUpdatedOnDesc();
	
}
