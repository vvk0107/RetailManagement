package com.vivek.RetailManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.vivek.RetailManagement.Exceptions.ErrorMessage;
import com.vivek.RetailManagement.Exceptions.NoStorePresent;
import com.vivek.RetailManagement.Exceptions.StoreAlreadyPresent;
import com.vivek.RetailManagement.ItemBean.StoreBean;
import com.vivek.RetailManagement.entity.Store;
import com.vivek.RetailManagement.service.StoreService;

@RestController
@CrossOrigin(origins = "*")
public class StoreController{
	@Autowired
	private StoreService service;
	
	@PostMapping("/addstore")
	public String savestore(@RequestBody StoreBean storebean){
		return service.saveStore(storebean);	}
	
	@GetMapping("/searchAllstore")
	public List<Store> searchAllStore(){
		return service.getAllstores();
	}
	
	@GetMapping("/searchStores")
    public List<Integer> searchStores(){
        return service.getStoreNumbers();
    }

	
	@GetMapping("/searchStore/{storeNumber}")
	public Store searchstore(@PathVariable int storeNumber) {
		return service.getstoreById(storeNumber);
	}
	@PutMapping("/updatestore")
	public String updatestore(@RequestBody StoreBean storebean) {
			return service.updateStore(storebean);
	}
	@DeleteMapping("/delete/{storeNumber}")
	public String deletestore(@PathVariable int storeNumber) {
			return service.deleteStore(storeNumber);
			
	
	}
	@ExceptionHandler(value= StoreAlreadyPresent.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorMessage handleStoreAlreadyPresent(StoreAlreadyPresent s) {
		return new ErrorMessage(HttpStatus.BAD_REQUEST.value(),s.getMessage());
	
	}
	@ExceptionHandler(value= NoStorePresent.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorMessage handleNoStorePresent(NoStorePresent s) {
		return new ErrorMessage(HttpStatus.BAD_REQUEST.value(),s.getMessage());
	
	}
}