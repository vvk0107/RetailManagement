package com.vivek.RetailManagement.entity;
import java.sql.Date;
import java.util.*;
import java.time.LocalDateTime;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.lang.NonNull;

import lombok.Data;

	@Entity
	@Data
	@Table(name="Item")

	public class Item {
	    @EmbeddedId
	    private ItemPrime itemPrime;
	    
	    private String itemName;
	    
	    private String itemType;
	    
	    @ManyToOne
	    @JoinColumn
	    private Store storeNumber;
	    
	    private Long itemPrice;
	    
	   
	    private Date itemEndDate;
	    private String supplierName;

	   @NonNull
	   @CreationTimestamp
	    private LocalDateTime createdOn;
	   
	   @UpdateTimestamp
	    private LocalDateTime updatedOn;

	public ItemPrime getItemPrime() {
		return itemPrime;
	}

	public void setItemPrime(ItemPrime itemPrime) {
		this.itemPrime = itemPrime;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public Store getStoreNumber() {
		return storeNumber;
	}

	public void setStoreNumber(Store storeNumber) {
		this.storeNumber = storeNumber;
	}

	public Long getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(Long itemPrice) {
		this.itemPrice = itemPrice;
	}

	public Date getItemEndDate() {
		return itemEndDate;
	}

	public void setItemEndDate(Date itemEndDate) {
		this.itemEndDate = itemEndDate;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public LocalDateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public LocalDateTime getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(LocalDateTime updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Item(ItemPrime itemPrime, String itemName, String itemType, Store storeNumber, Long itemPrice,
			Date itemEndDate, String supplierName, LocalDateTime createdOn, LocalDateTime updatedOn) {
		super();
		this.itemPrime = itemPrime;
		this.itemName = itemName;
		this.itemType = itemType;
		this.storeNumber = storeNumber;
		this.itemPrice = itemPrice;
		this.itemEndDate = itemEndDate;
		this.supplierName = supplierName;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}

	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	   
	   
	  		}