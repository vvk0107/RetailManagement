package com.vivek.RetailManagement.ItemBean;

import java.sql.Date;
import java.time.LocalDateTime;

import com.vivek.RetailManagement.entity.Store;

public class ItemBean {
	  	private String itemNumber;
	  	private Date itemStartDate;
	    private String itemName;
	    private String itemType;
	    private Integer storeNumber;
	    private Long itemPrice;  
	    private Date itemEndDate;
	    private String supplierName;
	    private LocalDateTime createdOn;
	    private LocalDateTime updatedOn;
		public String getItemNumber() {
			return itemNumber;
		}
		public void setItemNumber(String itemNumber) {
			this.itemNumber = itemNumber;
		}
		public Date getItemStartDate() {
			return itemStartDate;
		}
		public void setItemStartDate(Date itemStartDate) {
			this.itemStartDate = itemStartDate;
		}
		public String getItemName() {
			return itemName;
		}
		public void setItemName(String itemName) {
			this.itemName = itemName;
		}
		public String getItemType() {
			return itemType;
		}
		public void setItemType(String itemType) {
			this.itemType = itemType;
		}
		public Integer getStoreNumber() {
			return storeNumber;
		}
		public void setStoreNumber(Integer storeNumber) {
			this.storeNumber = storeNumber;
		}
		public Long getItemPrice() {
			return itemPrice;
		}
		public void setItemPrice(Long itemPrice) {
			this.itemPrice = itemPrice;
		}
		public Date getItemEndDate() {
			return itemEndDate;
		}
		public void setItemEndDate(Date itemEndDate) {
			this.itemEndDate = itemEndDate;
		}
		public String getSupplierName() {
			return supplierName;
		}
		public void setSupplierName(String supplierName) {
			this.supplierName = supplierName;
		}
		public LocalDateTime getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(LocalDateTime createdOn) {
			this.createdOn = createdOn;
		}
		public LocalDateTime getUpdatedOn() {
			return updatedOn;
		}
		public void setUpdatedOn(LocalDateTime updatedOn) {
			this.updatedOn = updatedOn;
		}
		public ItemBean(String itemNumber, Date itemStartDate, String itemName, String itemType, Integer storeNumber,
				Long itemPrice, Date itemEndDate, String supplierName, LocalDateTime createdOn,
				LocalDateTime updatedOn) {
			super();
			this.itemNumber = itemNumber;
			this.itemStartDate = itemStartDate;
			this.itemName = itemName;
			this.itemType = itemType;
			this.storeNumber = storeNumber;
			this.itemPrice = itemPrice;
			this.itemEndDate = itemEndDate;
			this.supplierName = supplierName;
			this.createdOn = createdOn;
			this.updatedOn = updatedOn;
		}
		public ItemBean() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
	    
}