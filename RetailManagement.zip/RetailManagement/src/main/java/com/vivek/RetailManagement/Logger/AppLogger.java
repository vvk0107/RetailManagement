package com.vivek.RetailManagement.Logger;

public class AppLogger {
	    
	    public static final String ITEM_ADDED_MSG="Item Added Successfully";
	    public static final String ITEM_EXISTS_MSG="Item already Exists";
	    public static final String ITEM_UPDATE_MSG="Item is Updated Successfully";
	    public static final String ITEM_NOT_EXISTS_MSG= "Item does not exists";
	    public static final String ITEM_DELETE_MSG="Successfully deleted with store Number";
	    public static final String STORE_ADDED_MSG="Store Added Successfully";
	    public static final String STORE_NOT_EXISTS_MSG= "Store does not exists";
	    public static final String STORE_UPDATE_MSG="Store is Updated Successfully"; 
	    public static final String STORE_DELETE_MSG="Successfully deleted with store Number";
	    public static final String STORE_EXISTS_MSG="Store already Exists";

}
