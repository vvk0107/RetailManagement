package com.vivek.RetailManagement.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import com.vivek.RetailManagement.Exceptions.NoStorePresent;
import com.vivek.RetailManagement.Exceptions.StoreAlreadyPresent;
import com.vivek.RetailManagement.ItemBean.StoreBean;
import com.vivek.RetailManagement.Logger.AppLogger;
import com.vivek.RetailManagement.entity.Store;
import com.vivek.RetailManagement.repository.StoreRepository;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.Sort;
@Service
@Slf4j
public class StoreService {
	@Autowired
	private StoreRepository repository;

	public String saveStore(StoreBean storebean) {
		Store storeNew= new Store();
		
		storeNew.setStoreNumber(storebean.getStoreNumber());
		storeNew.setStoreName(storebean.getStoreName());
		storeNew.setStorePattern(storebean.getStorePattern());
		storeNew.setStoreLocation(storebean.getStoreLocation());
		storeNew.setState(storebean.getState());
		storeNew.setPinCode(storebean.getPinCode());
		storeNew.setStoreStartDate(storebean.getStoreStartDate());
		storeNew.setStoreEndDate(storebean.getStoreEndDate());
		
		repository.findById(storeNew.getStoreNumber()).ifPresent(consumer->{
			log.error(AppLogger.STORE_EXISTS_MSG);
			throw new StoreAlreadyPresent("Store already exists");});
		repository.save(storeNew);
		log.error(AppLogger.STORE_NOT_EXISTS_MSG);
		return "Store added";
	}
	public List<Store> getAllstores() {
//		return repository.findAll();
		// repository.findAll(Sort.by(Direction.DESC,"updatedOn"));
	        return repository.FindAllByOrderByUpdatedOnDesc();
	    }
	
	public List<Integer> getStoreNumbers() {
        return repository.findStores();
    }

	public Store getstoreById(int storeNumber) {
			return repository.findById(storeNumber).orElseThrow(()->
			new NoStorePresent("No Store Present"));
	}
	
	public String deleteStore(int storeNumber) {
		try {
			if (repository.existsById(storeNumber))
			{
			repository.deleteById(storeNumber);
			log.error(AppLogger.STORE_DELETE_MSG);
			return "Product deleted sucessfully:  " + storeNumber;	
			}
			log.error(AppLogger.STORE_NOT_EXISTS_MSG);
			return ("No store available for this ID to delete");
		}catch(IllegalArgumentException e) {
			return ("Illegal Argument");
		}
	}

	public String updateStore(StoreBean storebean) {
			
		Store storeNew= new Store();
		storeNew.setStoreNumber(storebean.getStoreNumber());
		storeNew.setStoreName(storebean.getStoreName());
		storeNew.setStorePattern(storebean.getStorePattern());
		storeNew.setStoreLocation(storebean.getStoreLocation());
		storeNew.setState(storebean.getState());
		storeNew.setPinCode(storebean.getPinCode());
		storeNew.setStoreStartDate(storebean.getStoreStartDate());
		storeNew.setStoreEndDate(storebean.getStoreEndDate());
		storeNew.setCreatedOn(storebean.getCreatedOn());
		storeNew.setUpdatedOn(storebean.getUpdatedOn());
		
		repository.findById(storebean.getStoreNumber()).orElseThrow(()->
		new NoStorePresent("No store Available to update"));
		repository.save(storeNew);
		log.error(AppLogger.STORE_UPDATE_MSG);
		return "store updated";
	}
	public Store findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
