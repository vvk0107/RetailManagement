package com.vivek.RetailManagement.Exceptions;

import lombok.Data;

@Data
public class ErrorMessage {
	private int Status;
	private String Message;
	
	public ErrorMessage(String msg){
		super();
		this.Message=msg;
		
		
	}

	public int getStatus() {
		return Status;
	}

	public void setStatus(int status) {
		Status = status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}

	public ErrorMessage(int status, String message) {
		super();
		Status = status;
		Message = message;
	}

	public ErrorMessage() {
		super();
		// TODO Auto-generated constructor stub
	}

}
