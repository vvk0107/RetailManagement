package com.vivek.RetailManagement.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.vivek.RetailManagement.Exceptions.ItemAlreadyPresent;
import com.vivek.RetailManagement.Exceptions.NoItemPresent;
import com.vivek.RetailManagement.ItemBean.ItemBean;
import com.vivek.RetailManagement.Logger.AppLogger;
import com.vivek.RetailManagement.entity.Item;
import com.vivek.RetailManagement.entity.ItemPrime;
import com.vivek.RetailManagement.repository.ItemRepository;

import lombok.extern.slf4j.Slf4j;

import com.vivek.RetailManagement.entity.Store;
@Service
@Slf4j
public class ItemService {
	@Autowired
	private ItemRepository repository;

	public String saveItem(ItemBean itembean) {
		Item itemnew=new Item();
		Store store = new Store();
		ItemPrime itemprime= new ItemPrime();
		
		itemprime.setItemNumber(itembean.getItemNumber());
		itemprime.setItemStartDate(itembean.getItemStartDate());
		
		itemnew.setItemPrime(itemprime);
		itemnew.setItemName(itembean.getItemName());
		itemnew.setItemType(itembean.getItemType());
		
		store.setStoreNumber(itembean.getStoreNumber());
		
		itemnew.setStoreNumber(store);
		itemnew.setItemPrice(itembean.getItemPrice());
		itemnew.setItemEndDate(itembean.getItemEndDate());
		itemnew.setSupplierName(itembean.getSupplierName());
		itemnew.setCreatedOn(itembean.getCreatedOn());
		//itemnew.setUpdatedOn(itembean.getUpdatedOn());
		repository.findById(itemnew.getItemPrime()).ifPresent(consumer -> {
			log.error(AppLogger.ITEM_EXISTS_MSG);
			throw new ItemAlreadyPresent("Item already exists");});
		repository.save(itemnew);
		log.error(AppLogger.ITEM_ADDED_MSG);
		return "Item added"+ itemnew;	
	}
	public List<Item> getAllitems() {
		return repository.findAllByOrderByUpdatedOnDesc();
	}

	public ItemBean getitemById(String ItemNumber, Date ItemStartDate) {
			
			Item existItem= repository.findByIdDate(ItemNumber, ItemStartDate);
			if(existItem==null) {
				log.error(AppLogger.ITEM_NOT_EXISTS_MSG);
				throw new NoItemPresent("NO item present");
			}
			
			else {
				ItemBean itemBean = new ItemBean();
				itemBean.setItemNumber(existItem.getItemPrime().getItemNumber());
				itemBean.setItemStartDate(existItem.getItemPrime().getItemStartDate());
				itemBean.setItemName(existItem.getItemName());
				itemBean.setItemPrice(existItem.getItemPrice());
				itemBean.setItemType(existItem.getItemType());
				itemBean.setStoreNumber(existItem.getStoreNumber().getStoreNumber());
				itemBean.setSupplierName(existItem.getSupplierName());
				itemBean.setCreatedOn(existItem.getCreatedOn());
				//itemBean.setUpdatedOn(existItem.getUpdatedOn());
				itemBean.setItemEndDate(existItem.getItemEndDate());
				log.error(AppLogger.ITEM_EXISTS_MSG);
				return itemBean;
			}
			}
	
	public Boolean deleteItem(String ItemNumber, Date itemStartDate) {
		Item existItem=repository.findByIdDate(ItemNumber, itemStartDate);
		if (existItem==null)
		{
			log.error(AppLogger.ITEM_NOT_EXISTS_MSG);
			throw new NoItemPresent ("No Item available for this ID to delete");
			
		}else {
			repository.deleteById(ItemNumber, itemStartDate);	
			log.error(AppLogger.ITEM_DELETE_MSG);
			return true;
			}

//		return "Product deleted sucessfully" + ItemNumber + itemStartDate;
	}
	public String updateItem(ItemBean itembean) {
		
		Item itemnew = new Item();
		Store store = new Store();
		ItemPrime itemprime= new ItemPrime();
		itemprime.setItemNumber(itembean.getItemNumber());
		itemprime.setItemStartDate(itembean.getItemStartDate());
		itemnew.setItemPrime(itemprime);
		itemnew.setItemName(itembean.getItemName());
		itemnew.setItemType(itembean.getItemType());
		store.setStoreNumber(itembean.getStoreNumber());
		itemnew.setStoreNumber(store);
		itemnew.setItemPrice(itembean.getItemPrice());
		itemnew.setItemEndDate(itembean.getItemEndDate());
		itemnew.setSupplierName(itembean.getSupplierName());
		itemnew.setCreatedOn(itembean.getCreatedOn());
		
		repository.findById(itemnew.getItemPrime()).orElseThrow(()->
		new NoItemPresent("No Item Available to update"));
		repository.save(itemnew);
		log.error(AppLogger.ITEM_UPDATE_MSG);
		return "item updated";
	
	}
}

