package com.vivek.RetailManagement.controller;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.vivek.RetailManagement.Exceptions.ErrorMessage;
import com.vivek.RetailManagement.Exceptions.ItemAlreadyPresent;
import com.vivek.RetailManagement.Exceptions.NoItemPresent;
import com.vivek.RetailManagement.ItemBean.ItemBean;
import com.vivek.RetailManagement.entity.Item;
import com.vivek.RetailManagement.service.ItemService;   

@RestController
@CrossOrigin(origins = "*")
public class ItemController{
	@Autowired
	private ItemService service;
	
	@PostMapping("/addItem")
	public String saveItem(@RequestBody ItemBean itembean) {
		service.saveItem(itembean);
		return "Item added";
	}
		
	@GetMapping("/searchAllitem")
	public List<Item> searchAllitem(){
		return service.getAllitems();
		
	}
//	@RequestMapping(method=RequestMethod.GET, value="/searchItem/{itemNumber}/{itemStartDate}")
//	public ItemBean searchitem(@PathVariable(name="itemNumber") String itemNumber, @PathVariable(name="itemStartDate") Date itemStartDate) {
//		return service.getitemById(itemNumber,itemStartDate);
//	}
	
	
//	@GetMapping("/searchItem")
//	public ItemBean searchitem(@RequestParam String ItemNumber, @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd")Date ItemStartDate) {
//		return service.getitemById(ItemNumber,ItemStartDate);
//	}
	@GetMapping("/searchItem/{ItemNumber}/{ItemStartDate}")
	public ItemBean searchitem(@PathVariable String ItemNumber, @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd")Date ItemStartDate) {
		return service.getitemById(ItemNumber,ItemStartDate);
	}
	
	
	
	
	@PutMapping("/updateitem")
	public String updateitem(@RequestBody ItemBean itembean) {
			return service.updateItem(itembean);
	}
	@DeleteMapping("/deleteitem/{ItemNumber}/{ItemStartDate}")
	public Boolean deleteitem(@PathVariable String ItemNumber, @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd")Date ItemStartDate)
	
	{
		return service.deleteItem(ItemNumber,ItemStartDate);
	
	}
	@ExceptionHandler(value= ItemAlreadyPresent.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorMessage handleItemAlreadyPresent(ItemAlreadyPresent v) {
		return new ErrorMessage(HttpStatus.BAD_REQUEST.value(),v.getMessage());
	
	}
	@ExceptionHandler(value= NoItemPresent.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorMessage handleNoItemPresent(NoItemPresent v) {
		return new ErrorMessage(HttpStatus.BAD_REQUEST.value(),v.getMessage());
	}
}