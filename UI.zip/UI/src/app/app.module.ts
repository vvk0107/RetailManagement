import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StoreComponent } from './store/store.component';
import { InputTextModule } from 'primeng/inputtext';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { StoreService } from './store.service';
import { ItemService } from './item.service';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { StoreOpComponent } from './store-op/store-op.component';
import { PaginatorModule } from "primeng/paginator";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableModule } from 'primeng/table';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmPopupModule} from 'primeng/confirmpopup';
import { ToastModule } from 'primeng/toast';
import { ItemCreateComponent } from './item-create/item-create.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { ItemOpComponent } from './item-op/item-op.component';
import { TooltipModule } from 'primeng/tooltip';
import { SpinnerComponent } from './spinner/spinner.component';
import { LoadingInterceptor } from './loading.interceptor';
import { ImageModule } from 'primeng/image';
import { MenubarModule } from 'primeng/menubar';

@NgModule({
  declarations: [
    AppComponent,
    StoreComponent,
    StoreOpComponent,
    ItemCreateComponent,
    MainpageComponent,
    ItemOpComponent,
    SpinnerComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    InputTextModule,
    HttpClientModule,
    FormsModule,ReactiveFormsModule,
    ButtonModule,
    PaginatorModule,
    BrowserAnimationsModule,
    TableModule,
    ToastModule,
    ConfirmPopupModule,
    TooltipModule,
    ImageModule,
    MenubarModule,
  ],
  providers: [StoreService, ConfirmationService, MessageService, ItemService, {
    provide: HTTP_INTERCEPTORS, useClass: LoadingInterceptor, multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
