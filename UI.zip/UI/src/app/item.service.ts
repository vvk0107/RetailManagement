import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ItemService {

    constructor(private http:HttpClient) { }
    private refreshrequired = new Subject<void>();
    get Refreshrequired(){
      return this.refreshrequired;
    }
  
  public createitem(itemBean){
    return this.http.post("http://localhost:8080/addItem",itemBean,{responseType:'text' as 'json'}).pipe(
      tap(()=>{
        this.refreshrequired.next();
      })
    );;
  }
   public SearchItem(){
     return this.http.get("http://localhost:8080/searchAllitem");
   }
  public SearchByItemNumber(itemNumber:any, itemStartDate:any){
    return this.http.get("http://localhost:8080/searchItem/"+itemNumber+"/"+itemStartDate);
    
  }
  public DeleteItem(itemNumber,itemStartDate){
     return this.http.delete("http://localhost:8080/deleteitem/"+itemNumber+"/"+itemStartDate).pipe(
      tap(()=>{
        this.refreshrequired.next();
      })
    );;
   }
  public UpdateItem(itemBean){
    return this.http.put("http://localhost:8080/updateitem",itemBean,{responseType:'text' as 'json'});
  }

  public getStores(){
    return this.http.get("http://localhost:8080/searchStores");
  }




}
