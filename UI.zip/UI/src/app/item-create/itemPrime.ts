export class itemPrime{
    itemNumber:String;
    itemStartDate:Date;
   }