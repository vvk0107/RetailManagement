import { ItemService } from '../item.service';
import { itemBean } from './itembean';
import { ActivatedRoute,Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-create',
  templateUrl: './item-create.component.html',
  styleUrls: ['./item-create.component.css']
})
export class ItemCreateComponent implements OnInit {
  itemBean : any = new itemBean();
  flag:boolean = false;
  msg:any;
  store: any;

    constructor(private service:ItemService, private router:Router, private activatedRoute: ActivatedRoute, private messageService:MessageService) { 

      this.service.getStores().subscribe(data=>

        {
        console.log(this.store);
        this.store=data;
      });
  
    }
    ngOnInit() {
      let itemNumber=this.activatedRoute.snapshot.paramMap.get("itemNumber");
      let itemStartDate=this.activatedRoute.snapshot.paramMap.get("itemStartDate");
      if (itemNumber!=null && itemStartDate!=null){
        this.flag=true;
      this.service.SearchByItemNumber(itemNumber,itemStartDate).subscribe(data=>{this.itemBean=data;})
  
      }
    }
    
    public create(){
      if(this.itemBean.itemNumber==null || this.itemBean.itemNumber==''){
        this.messageService.add({severity:'error', summary: 'Error Message', detail: "Item Number can't be blank"});
      }else
        if(this.itemBean.itemName==null || this.itemBean.itemName==''){
          this.messageService.add({severity:'error', summary: 'Error Message', detail: "Item Name can't be blank"});
  
      }else
      if(this.itemBean.itemType==null || this.itemBean.itemType==''){
        this.messageService.add({severity:'error', summary: 'Error Message', detail: "Item Type can't be blank"});

    }else
    if(this.itemBean.itemPrice==null || this.itemBean.itemPrice==0){
      this.messageService.add({severity:'error', summary: 'Error Message', detail: "Item Price can't be blank"});

  }else
  if(this.itemBean.storeNumber==null || this.itemBean.storeNumber==''){
    this.messageService.add({severity:'error', summary: 'Error Message', detail: "Store Number can't be blank"});

}else 
      if(this.itemBean.itemStartDate==null || this.itemBean.itemStartDate==''){
        this.messageService.add({severity:'error', summary: 'Error Message', detail: "Item Start Date can't be blank"});
      }
      else
    if(this.itemBean.itemStartDate!>this.itemBean.itemEndDate ){
      this.messageService.add({severity:'error', summary: 'Error Message', detail: 'Item Start Date Should Not Be Greater Than Item End Date'});
    }
      else{
  
        this.service.createitem(this.itemBean).subscribe(
          data=>{
        
          this.msg=data; });
          sessionStorage.setItem("successMessage", "AddedSuccess");
          this.router.navigate(['/searchAllitem']); 
   }}
    
  
  
    UpdateMyItem(){
      this.service.UpdateItem(this.itemBean).subscribe(data =>{this.msg=data;});
      


      sessionStorage.setItem("successMessage", "UpdateSuccess");
      this.router.navigate(['searchAllitem']);
    }
  
  
    goToPage(){
      this.router.navigate(['searchAllitem']);
    }
  }
