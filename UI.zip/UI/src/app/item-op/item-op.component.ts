import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ItemService } from '../item.service';
import { ConfirmationService } from 'primeng/api';
import { HttpClient } from '@angular/common/http';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-item-op',
  templateUrl: './item-op.component.html',
  styleUrls: ['./item-op.component.css']
})
export class ItemOpComponent implements OnInit {

  itemBean: any;
  display:boolean= false;
  constructor(private service:ItemService, private router: Router, private confirmService: ConfirmationService, private messageService : MessageService) {
  
    setTimeout(() => {
      if (sessionStorage.getItem("successMessage") == 'AddedSuccess') {
        this.messageService.add({ severity: 'success', summary: 'Success Message', detail: "Record added successfully!" });
      }
      if (sessionStorage.getItem("successMessage") == 'UpdateSuccess') {
        this.messageService.add({ severity: 'success', summary: 'Success Message', detail: "Record updated successfully!" });
      }
      console.log(sessionStorage.getItem("successMessage"));
      sessionStorage.removeItem("successMessage");
    });

  }
  ngOnInit() {
    //  this.SpinnerService.show();
    //  setTimeout(() => {
    //    this.SpinnerService.hide();
    //  }, 5000);
this.fetchData();

      this.service.Refreshrequired.subscribe(Response=>{
        this.ngOnInit();
        })
  }

  public deleteItemNow(itemNumber:number,itemStartDate:Date){
    this.service.DeleteItem(itemNumber,itemStartDate).subscribe(
      data=>{this.itemBean=data}
      );
    // this.itemBean=this.itemBean.filter(s => s.itemNumber !== itemNumber && s.itemStartDate !== itemStartDate);
    // subscribe((data)=>this.itemBean=data);
    if(this.itemBean!=null)
    this.fetchData();
  }

  
showDialog(){
 this.display=true;
}
 confirm(event: Event,itemNumber:any,itemStartDate:any) {

 this.confirmService.confirm({
    target: event.target as EventTarget,
     message: 'Are you sure you want to delete the item?',
     icon: 'pi pi-exclamation-circle',
      accept: () => {
        this.deleteItemNow(itemNumber,itemStartDate);
        console.log(itemNumber,itemStartDate);
        this.messageService.add({severity:'info', summary:'Confirmed', detail:'Item Deleted!!'});
 },
       reject: () => {
    this.messageService.add({severity:'error', summary:'Rejected', detail:'You Cancel Request!!'});
  }
}); 
}



  createItem(){
    this.router.navigate(['item']);
  }

  Home(){
    this.router.navigate(['']);
  }

  editItem(itemBean:any){
    let itemNumber=itemBean.itemPrime.itemNumber;
    let itemStartDate=itemBean.itemPrime.itemStartDate;    
    this.router.navigate(['updateitem',itemNumber,itemStartDate]);
  }

  fetchData(){
    debugger;
    this.service.SearchItem().subscribe(
      data=>{console.log(this.itemBean);
      this.itemBean=data});
  }

}
