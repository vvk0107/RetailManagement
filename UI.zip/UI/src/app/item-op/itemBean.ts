export class itemBean{
    itemNumber:String;
    itemStartDate:Date;
    itemName:String;
    itemType:String;
    storeNumber:Number;
    itemPrice:Number;
    itemEndDate:String;
    supplierName:String;
    createdOn:Date;
    updatedOn:Date;
   }