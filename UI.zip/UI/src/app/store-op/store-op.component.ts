import { Component, OnInit } from '@angular/core';
import { StoreService } from '../store.service';
import { Router } from '@angular/router';
import { ConfirmationService } from 'primeng/api';
import { HttpClient } from '@angular/common/http';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-store-op',
  templateUrl: './store-op.component.html',
  styleUrls: ['./store-op.component.css']
})
export class StoreOpComponent implements OnInit {
  storeOpBean:any; 
  storeNumber:number;
  display:boolean=false;
  constructor(private service:StoreService, private router:Router, private confirmationService: ConfirmationService, private messageService:MessageService) {
    
    setTimeout(() => {
      if (sessionStorage.getItem("successMessage") == 'AddedSuccess') {
        this.messageService.add({ severity: 'success', summary: 'Success Message', detail: "Record added successfully!" });
      }
      if (sessionStorage.getItem("successMessage") == 'UpdateSuccess') {
        this.messageService.add({ severity: 'success', summary: 'Success Message', detail: "Record updated successfully!" });
      }
      console.log(sessionStorage.getItem("successMessage"));
      sessionStorage.removeItem("successMessage");
    });

  }

  public Delete(storeNumber:number){
    let resp= this.service.DeleteStore(storeNumber);
    this.storeOpBean = this.storeOpBean.filter(i => i.storeNumber !== storeNumber);
    resp.subscribe((data)=>this.storeOpBean=data);
  }
  public FindByStoreNumber(){
    let resp= this.service.SearchByStoreNumber(this.storeOpBean);
    resp.subscribe((data)=>this.storeOpBean=data);
  }
  public UpdateMyStore(storeNumber:number){
    this.router.navigate(['updatestore',storeNumber]);
  }

  ngOnInit() {
     let res=this.service.SearchStore();
     res.subscribe((data)=>this.storeOpBean=data);
  }
  createStore(){
    this.router.navigate(['store']);
  }

  Home(){
    this.router.navigate(['']);
  }
  
showDialog() {
 this.display=true;
}
confirm(event:Event,storeNumber:any){
  this.confirmationService.confirm({
    target: event.target as EventTarget,
    message: 'Are you sure you want to DELETE the Store?',
    icon:'pi pi-exclamation-triangle',
    accept:()=>{
      //confirm action
    this.Delete(storeNumber)
    this.messageService.add({severity:'info', summary:'Success', detail:'store deleted'});
    this.router.navigate(["searchAllstore"])
    },

  reject:()=>{
    //reject action
    this.messageService.add({severity:'error', summary:'Rejected', detail:'You Cancel Request!!'});
    }
  });
}


}
