import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mainpage',
  templateUrl: './mainpage.component.html',
  styleUrls: ['./mainpage.component.css']
})
export class MainpageComponent implements OnInit {
items: any;
  constructor(private router: Router) { }

  ngOnInit() {
    this.items=[
      {
        label: 'Store',
        command: () => this.createstore(),
      },
      {
        label: 'Item',
        command: () => this.createitem(),
      }
    ];
 }

  createstore(){
    this.router.navigate(['searchAllstore']);
  }

  createitem(){
    this.router.navigate(['searchAllitem']);
  }

  addStore() {
    this.router.navigate(['store']);
  }
    addItem() {
    this.router.navigate(['item']);  
  }

}
