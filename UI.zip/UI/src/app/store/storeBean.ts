 
export class storeBean{
 storeNumber:number;
 storeName:string;
 storePattern:string;
 storeLocation:string;
 state:string;
 pinCode:number;
 storeStartDate:Date;
 storeEndDate:Date;
 createdOn:Date;
 updatedOn:Date;
}

