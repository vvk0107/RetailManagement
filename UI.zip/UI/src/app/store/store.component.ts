import { Component, OnInit } from '@angular/core';
import { StoreService } from '../store.service';
import { storeBean } from './storebean';
import { ActivatedRoute,Router } from '@angular/router';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-store',
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.css']
})

export class StoreComponent implements OnInit {
storeBean : any = new storeBean();
flag:boolean = false;
msg:any;
  constructor(private service:StoreService, private router:Router, private activatedRoute: ActivatedRoute, private messageService:MessageService) { }
  ngOnInit() {
    let storeNumber=this.activatedRoute.snapshot.paramMap.get("storeNumber");
    if (storeNumber!=null){
      this.flag=true;
    this.service.SearchByStoreNumber(storeNumber).subscribe(data=>{this.storeBean=data;})

    }
  }
  
  public create(){
    if(this.storeBean.storeNumber==null || this.storeBean.storeNumber==''){
      this.messageService.add({severity:'error', summary: 'Error Message', detail: "Store Number can't be blank"});
    }else
      if(this.storeBean.storeName==null || this.storeBean.storeName==''){
        this.messageService.add({severity:'error', summary: 'Error Message', detail: "Store Name can't be blank"});

    }else 
    if(this.storeBean.storeStartDate==null || this.storeBean.storeStartDate==''){
      this.messageService.add({severity:'error', summary: 'Error Message', detail: "Store Start Date can't be blank"});
    }
    else
    if(this.storeBean.storeStartDate!>this.storeBean.storeEndDate ){
      this.messageService.add({severity:'error', summary: 'Error Message', detail: 'Store Start Date Should Not Be Greater Than Item End Date'});
    }
    else{

      this.service.createstore(this.storeBean).subscribe(
        data=>{
        
        this.msg=data;
        sessionStorage.setItem("successMessage", "AddedSuccess");
        this.router.navigate(['/searchAllstore']); 
  });}}
  


  UpdateMyStore(){
    this.service.UpdateStore(this.storeBean).subscribe(data =>{this.msg=data;});
    sessionStorage.setItem("successMessage", "UpdateSuccess");
    this.router.navigate(['searchAllstore']);
  }


  goToPage(){
    this.router.navigate(['searchAllstore']);
  }
}
