import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StoreComponent } from './store/store.component';
import { StoreOpComponent } from './store-op/store-op.component';
import { ItemOpComponent } from './item-op/item-op.component';
import { ItemCreateComponent } from './item-create/item-create.component';
import { MainpageComponent } from './mainpage/mainpage.component';
const routes: Routes = [
  {path:"", component: MainpageComponent},
  {path:"store", component: StoreComponent},
  {path:"searchAllstore", component: StoreOpComponent},
  {path:"updatestore/:storeNumber", component: StoreComponent},
  {path:"item", component: ItemCreateComponent },
  {path:"searchAllitem", component: ItemOpComponent},
  {path:"updateitem/:itemNumber/:itemStartDate", component: ItemCreateComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
