import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StoreService {

  constructor(private http:HttpClient) { }

public createstore(storeBean){
  return this.http.post("http://localhost:8080/addstore",storeBean,{responseType:'text' as 'json'});
}
public SearchStore(){
  return this.http.get("http://localhost:8080/searchAllstore");
}
public SearchByStoreNumber(storeNumber){
  return this.http.get("http://localhost:8080/searchStore/"+storeNumber);
}
public DeleteStore(storeNumber){
  return this.http.delete("http://localhost:8080/delete/"+storeNumber);
}
public UpdateStore(storeBean){
  return this.http.put("http://localhost:8080/updatestore",storeBean,{responseType:'text' as 'json'});
}
}